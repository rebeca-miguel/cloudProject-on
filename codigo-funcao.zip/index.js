exports.welcomeMessage = (req, res) => {
    res.status(200).send("Bem-vindo(a) ao projeto na nuvem!");
  };
  